export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      achievements: {
        Row: {
          id: string
          key: string
          unlocked_at: string
          user_id: string
        }
        Insert: {
          id?: string
          key: string
          unlocked_at?: string
          user_id: string
        }
        Update: {
          id?: string
          key?: string
          unlocked_at?: string
          user_id?: string
        }
        Relationships: []
      }
      attribute_history: {
        Row: {
          attribute: string
          created_at: string
          delta: number
          id: string
          reason: string
          user_id: string
        }
        Insert: {
          attribute: string
          created_at?: string
          delta: number
          id?: string
          reason: string
          user_id: string
        }
        Update: {
          attribute?: string
          created_at?: string
          delta?: number
          id?: string
          reason?: string
          user_id?: string
        }
        Relationships: []
      }
      level_history: {
        Row: {
          created_at: string
          id: string
          level: number
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          level: number
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          level?: number
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          attribute_points: number
          attributes: Json
          avatar_color: string
          created_at: string
          current_streak: number
          display_name: string
          id: string
          last_streak_day: string | null
          last_sync_day: string | null
          level: number
          longest_streak: number
          quests_completed: number
          timezone: string
          total_xp: number
          xp: number
        }
        Insert: {
          attribute_points?: number
          attributes?: Json
          avatar_color?: string
          created_at?: string
          current_streak?: number
          display_name?: string
          id: string
          last_streak_day?: string | null
          last_sync_day?: string | null
          level?: number
          longest_streak?: number
          quests_completed?: number
          timezone?: string
          total_xp?: number
          xp?: number
        }
        Update: {
          attribute_points?: number
          attributes?: Json
          avatar_color?: string
          created_at?: string
          current_streak?: number
          display_name?: string
          id?: string
          last_streak_day?: string | null
          last_sync_day?: string | null
          level?: number
          longest_streak?: number
          quests_completed?: number
          timezone?: string
          total_xp?: number
          xp?: number
        }
        Relationships: []
      }
      quest_log: {
        Row: {
          created_at: string
          day: string
          id: string
          outcome: string
          quest_id: string
          user_id: string
          xp: number
        }
        Insert: {
          created_at?: string
          day: string
          id?: string
          outcome: string
          quest_id: string
          user_id: string
          xp?: number
        }
        Update: {
          created_at?: string
          day?: string
          id?: string
          outcome?: string
          quest_id?: string
          user_id?: string
          xp?: number
        }
        Relationships: [
          {
            foreignKeyName: "quest_log_quest_id_fkey"
            columns: ["quest_id"]
            isOneToOne: false
            referencedRelation: "quests"
            referencedColumns: ["id"]
          },
        ]
      }
      quests: {
        Row: {
          archived: boolean
          attribute: string
          created_at: string
          description: string
          difficulty: string
          due_date: string | null
          id: string
          recurrence: string
          title: string
          user_id: string
        }
        Insert: {
          archived?: boolean
          attribute: string
          created_at?: string
          description?: string
          difficulty?: string
          due_date?: string | null
          id?: string
          recurrence?: string
          title: string
          user_id: string
        }
        Update: {
          archived?: boolean
          attribute?: string
          created_at?: string
          description?: string
          difficulty?: string
          due_date?: string | null
          id?: string
          recurrence?: string
          title?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      allocate_point: { Args: { p_attr: string }; Returns: undefined }
      check_achievements: { Args: { p_uid: string }; Returns: string[] }
      complete_quest: { Args: { p_quest: string }; Returns: Json }
      delete_my_account: { Args: never; Returns: undefined }
      difficulty_attr: { Args: { d: string }; Returns: number }
      difficulty_xp: { Args: { d: string }; Returns: number }
      grant_achievement: {
        Args: { p_key: string; p_uid: string }
        Returns: boolean
      }
      sync_day: { Args: never; Returns: Json }
      user_today: { Args: { p_uid: string }; Returns: string }
      xp_for_level: { Args: { l: number }; Returns: number }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
