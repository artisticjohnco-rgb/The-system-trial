import { createContext, useCallback, useContext, useState, type ReactNode } from "react";

type Alert = { title: string; lines?: string[]; tone?: "info" | "warn" };
const Ctx = createContext<(a: Alert) => void>(() => {});
export const useSystemAlert = () => useContext(Ctx);

export function SystemAlertProvider({ children }: { children: ReactNode }) {
  const [queue, setQueue] = useState<Alert[]>([]);
  const push = useCallback((a: Alert) => setQueue((q) => [...q, a]), []);
  const current = queue[0];
  return (
    <Ctx.Provider value={push}>
      {children}
      {current && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-background/70 p-6 backdrop-blur-sm"
          onClick={() => setQueue((q) => q.slice(1))}
        >
          <div
            key={queue.length + current.title}
            className={`panel glow-strong scanline animate-system-in w-full max-w-md p-8 text-center ${current.tone === "warn" ? "border-destructive" : ""}`}
          >
            <div className="mb-3 text-xs font-display text-muted-foreground">[ SYSTEM ]</div>
            <h2 className={`font-display text-2xl font-bold text-glow ${current.tone === "warn" ? "text-destructive" : "text-primary"}`}>
              {current.title}
            </h2>
            {current.lines?.map((l) => (
              <p key={l} className="mt-2 text-lg text-foreground">{l}</p>
            ))}
            <p className="mt-6 text-xs text-muted-foreground">Tap to continue</p>
          </div>
        </div>
      )}
    </Ctx.Provider>
  );
}
