import { Check, Trash2, X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { attrLabel, achievementTitle, difficultyXp } from "@/lib/game";
import { useSystemAlert } from "./SystemAlert";
import type { Tables } from "@/integrations/supabase/types";

export function QuestCard({
  quest,
  status,
  onDelete,
}: {
  quest: Tables<"quests">;
  status: "pending" | "completed" | "failed";
  onDelete?: () => void;
}) {
  const [busy, setBusy] = useState(false);
  const qc = useQueryClient();
  const alert = useSystemAlert();

  async function complete() {
    if (busy || status !== "pending") return;
    setBusy(true);
    const { data, error } = await supabase.rpc("complete_quest", { p_quest: quest.id });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    const r = data as {
      xp: number; attribute: string; attribute_gain: number; leveled_up: boolean; level: number;
      achievements: string[]; daily_clear: boolean;
    };
    toast.success(`QUEST COMPLETED · +${r.xp} XP · ${attrLabel(r.attribute)} +${r.attribute_gain}`);
    if (r.leveled_up) alert({ title: "LEVEL UP", lines: [`You have reached Level ${r.level}.`, "+3 attribute points available."] });
    r.achievements.forEach((a) => alert({ title: "ACHIEVEMENT UNLOCKED", lines: [achievementTitle(a)] }));
    qc.invalidateQueries();
  }

  return (
    <div className={`panel flex items-center gap-4 p-4 transition-opacity ${status !== "pending" ? "opacity-60" : ""}`}>
      <div className="grid h-11 w-11 shrink-0 place-items-center rounded-md border border-primary/40 font-display text-lg font-bold text-primary">
        {quest.difficulty}
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-xs font-display text-muted-foreground">
          [{attrLabel(quest.attribute).toUpperCase()}] · {quest.recurrence === "daily" ? "DAILY" : quest.due_date ? `DUE ${quest.due_date}` : "ONE-TIME"}
        </div>
        <div className={`truncate text-lg font-bold ${status === "completed" ? "line-through" : ""}`}>{quest.title}</div>
        {quest.description && <div className="truncate text-sm text-muted-foreground">{quest.description}</div>}
      </div>
      <div className="hidden shrink-0 text-right sm:block">
        <div className="font-display text-sm text-primary">+{difficultyXp(quest.difficulty)} XP</div>
      </div>
      {onDelete && (
        <button aria-label="Delete quest" onClick={onDelete} className="shrink-0 p-2 text-muted-foreground hover:text-destructive">
          <Trash2 className="h-4 w-4" />
        </button>
      )}
      <button
        aria-label="Complete quest"
        onClick={complete}
        disabled={busy || status !== "pending"}
        className={`grid h-11 w-11 shrink-0 place-items-center rounded-md border transition-all ${
          status === "completed"
            ? "border-success bg-success/20 text-success"
            : status === "failed"
              ? "border-destructive text-destructive"
              : "border-primary/60 text-primary hover:bg-primary/15 hover:shadow-[var(--shadow-glow)]"
        }`}
      >
        {status === "failed" ? <X className="h-5 w-5" /> : <Check className={`h-5 w-5 ${status === "pending" ? "opacity-30" : ""}`} />}
      </button>
    </div>
  );
}
