import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { Home, Swords, User, Trophy, Settings, LogOut } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useSystemAlert } from "./SystemAlert";

const NAV = [
  { to: "/", label: "System", icon: Home },
  { to: "/quests", label: "Quests", icon: Swords },
  { to: "/character", label: "Character", icon: User },
  { to: "/achievements", label: "Achievements", icon: Trophy },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const alert = useSystemAlert();
  const [ready, setReady] = useState(false);
  const synced = useRef(false);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if (!session) navigate({ to: "/auth" });
    });
    supabase.auth.getSession().then(async ({ data }) => {
      if (!data.session) return navigate({ to: "/auth" });
      setReady(true);
      if (synced.current) return;
      synced.current = true;
      // Set timezone on first use, then resolve missed deadlines.
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
      const { data: p } = await supabase.from("profiles").select("timezone,last_sync_day").eq("id", data.session.user.id).single();
      if (p && p.timezone === "UTC" && !p.last_sync_day && tz) {
        await supabase.from("profiles").update({ timezone: tz }).eq("id", data.session.user.id);
      }
      const { data: res } = await supabase.rpc("sync_day");
      const r = res as { failed: number; penalty: number } | null;
      if (r && r.failed > 0) {
        alert({
          title: "WARNING: QUESTS FAILED",
          tone: "warn",
          lines: [`${r.failed} quest(s) were not completed in time.`, `Penalty: −${r.penalty} XP`],
        });
      }
      qc.invalidateQueries();
    });
    return () => sub.subscription.unsubscribe();
  }, [navigate, qc, alert]);

  if (!ready) {
    return (
      <div className="grid min-h-screen place-items-center">
        <p className="font-display text-sm text-primary text-glow animate-pulse">CONNECTING TO THE SYSTEM…</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen md:flex">
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r border-sidebar-border bg-sidebar p-5 backdrop-blur md:flex">
        <div className="mb-10 font-display text-lg font-bold text-primary text-glow">THE SYSTEM</div>
        <nav className="flex flex-1 flex-col gap-1">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              activeOptions={{ exact: n.to === "/" }}
              className="flex items-center gap-3 rounded-md px-3 py-2 text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground"
              activeProps={{ className: "bg-sidebar-accent text-primary shadow-[var(--shadow-glow)]" }}
            >
              <n.icon className="h-4 w-4" />
              <span className="font-semibold tracking-wide">{n.label}</span>
            </Link>
          ))}
        </nav>
        <button
          onClick={() => supabase.auth.signOut()}
          className="flex items-center gap-3 rounded-md px-3 py-2 text-muted-foreground hover:text-destructive"
        >
          <LogOut className="h-4 w-4" /> Sign out
        </button>
      </aside>
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 pb-28 pt-6 md:px-8 md:pb-10">{children}</main>
      <nav className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t border-sidebar-border bg-sidebar backdrop-blur md:hidden">
        {NAV.map((n) => (
          <Link
            key={n.to}
            to={n.to}
            activeOptions={{ exact: n.to === "/" }}
            className="flex flex-col items-center gap-1 py-3 text-[11px] text-muted-foreground"
            activeProps={{ className: "text-primary" }}
          >
            <n.icon className="h-5 w-5" />
            {n.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}

export function PageTitle({ kicker, title }: { kicker: string; title: string }) {
  return (
    <header className="mb-6">
      <div className="font-display text-xs text-muted-foreground">{kicker}</div>
      <h1 className="font-display text-2xl font-bold text-primary text-glow md:text-3xl">{title}</h1>
    </header>
  );
}

export function XpBar({ value, max }: { value: number; max: number }) {
  const pct = Math.min(100, (value / Math.max(1, max)) * 100);
  return (
    <div className="h-2.5 w-full overflow-hidden rounded-full bg-muted">
      <div className="xp-fill h-full rounded-full" style={{ width: `${pct}%` }} />
    </div>
  );
}
