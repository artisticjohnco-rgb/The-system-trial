import { createFileRoute } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { AppShell, PageTitle, XpBar } from "@/components/AppShell";
import { useSystemAlert } from "@/components/SystemAlert";
import { supabase } from "@/integrations/supabase/client";
import { useHistory, useProfile } from "@/lib/data";
import { ATTRIBUTES, attrLabel, rankFor } from "@/lib/game";

export const Route = createFileRoute("/character")({
  head: () => ({
    meta: [
      { title: "Character — The System" },
      { name: "description", content: "Your status window: attributes, rank and progression history." },
      { property: "og:title", content: "Character — The System" },
      { property: "og:description", content: "Your status window: attributes, rank and progression history." },
    ],
  }),
  component: () => (
    <AppShell>
      <Character />
    </AppShell>
  ),
});

function Character() {
  const qc = useQueryClient();
  const alert = useSystemAlert();
  const { data: p } = useProfile();
  const { data: h } = useHistory();
  if (!p) return null;

  async function allocate(key: string) {
    const { error } = await supabase.rpc("allocate_point", { p_attr: key });
    if (error) { toast.error(error.message); return; }
    alert({ title: "ATTRIBUTE INCREASED", lines: [`${attrLabel(key)} +1`] });
    qc.invalidateQueries();
  }

  return (
    <div className="space-y-6">
      <PageTitle kicker="[ STATUS WINDOW ]" title="CHARACTER" />
      <section className="panel grid gap-4 p-5 sm:grid-cols-4">
        <Info label="Name" value={p.display_name} />
        <Info label="Level" value={p.level} />
        <Info label="Rank" value={rankFor(p.level)} />
        <Info label="Total XP" value={p.total_xp} />
      </section>
      {p.attribute_points > 0 && (
        <p className="font-display text-sm text-primary text-glow">
          {p.attribute_points} ATTRIBUTE POINT{p.attribute_points > 1 ? "S" : ""} AVAILABLE
        </p>
      )}
      <section className="grid gap-3 sm:grid-cols-2">
        {ATTRIBUTES.map((a) => {
          const v = Number(p.attributes[a.key] ?? 10);
          return (
            <div key={a.key} className="panel p-4">
              <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
                <div className="min-w-0">
                  <div className="font-display text-xs text-muted-foreground">{a.short}</div>
                  <div className="truncate text-lg font-bold">{a.label}</div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-display text-2xl font-bold text-primary">{v.toFixed(1)}</span>
                  {p.attribute_points > 0 && (
                    <button aria-label={`Add point to ${a.label}`} onClick={() => allocate(a.key)} className="grid h-8 w-8 place-items-center rounded-md border border-primary text-primary hover:bg-primary/20">
                      <Plus className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>
              <div className="mt-2"><XpBar value={v} max={100} /></div>
              <p className="mt-2 text-sm text-muted-foreground">{a.desc}</p>
            </div>
          );
        })}
      </section>
      <div className="grid gap-6 md:grid-cols-2">
        <section className="panel p-5">
          <h2 className="mb-3 font-display text-sm text-primary">ATTRIBUTE HISTORY</h2>
          <ul className="max-h-80 space-y-1 overflow-y-auto text-sm">
            {h?.attributes.map((r) => (
              <li key={r.id} className="flex justify-between gap-3">
                <span className="truncate text-muted-foreground">{r.reason}</span>
                <span className="shrink-0 text-success">{attrLabel(r.attribute)} +{Number(r.delta)}</span>
              </li>
            ))}
            {h?.attributes.length === 0 && <li className="text-muted-foreground">No changes yet.</li>}
          </ul>
        </section>
        <section className="panel p-5">
          <h2 className="mb-3 font-display text-sm text-primary">LEVEL HISTORY</h2>
          <ul className="space-y-1 text-sm">
            {h?.levels.map((r) => (
              <li key={r.id} className="flex justify-between">
                <span>Reached level {r.level}</span>
                <span className="text-muted-foreground">{new Date(r.created_at).toLocaleDateString()}</span>
              </li>
            ))}
            {h?.levels.length === 0 && <li className="text-muted-foreground">No level-ups yet.</li>}
          </ul>
        </section>
      </div>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="min-w-0">
      <div className="font-display text-[10px] text-muted-foreground">{label.toUpperCase()}</div>
      <div className="truncate text-xl font-bold">{value}</div>
    </div>
  );
}
