import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { AppShell, PageTitle } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useProfile } from "@/lib/data";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — The System" },
      { name: "description", content: "Player name, timezone, data export and account management." },
      { property: "og:title", content: "Settings — The System" },
      { property: "og:description", content: "Player name, timezone, data export and account management." },
    ],
  }),
  component: () => (
    <AppShell>
      <SettingsPage />
    </AppShell>
  ),
});

function SettingsPage() {
  const qc = useQueryClient();
  const { data: p } = useProfile();
  const [name, setName] = useState("");
  const [tz, setTz] = useState("");
  useEffect(() => {
    if (p) { setName(p.display_name); setTz(p.timezone); }
  }, [p]);
  if (!p) return null;

  async function save() {
    try { new Intl.DateTimeFormat("en", { timeZone: tz }); } catch { { toast.error("Unknown timezone"); return; } }
    const { error } = await supabase.from("profiles").update({ display_name: name.trim() || "Hunter", timezone: tz }).eq("id", p!.id);
    if (error) { toast.error(error.message); return; }
    toast.success("Saved.");
    qc.invalidateQueries({ queryKey: ["profile"] });
  }

  async function exportData() {
    const tables = ["profiles", "quests", "quest_log", "attribute_history", "level_history", "achievements"] as const;
    const out: Record<string, unknown> = {};
    for (const t of tables) out[t] = (await supabase.from(t).select("*")).data;
    const blob = new Blob([JSON.stringify(out, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "system-export.json";
    a.click();
  }

  async function removeAccount() {
    if (!confirm("Permanently delete your account and all progress? This cannot be undone.")) return;
    try {
      const { error } = await supabase.rpc("delete_my_account");
      if (error) throw error;
      await supabase.auth.signOut();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete failed");
    }
  }

  return (
    <div className="space-y-6">
      <PageTitle kicker="[ CONFIGURATION ]" title="SETTINGS" />
      <section className="panel space-y-3 p-5">
        <label className="block text-sm text-muted-foreground">Player name
          <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={40} className="mt-1" />
        </label>
        <label className="block text-sm text-muted-foreground">Timezone (daily reset at local midnight)
          <Input value={tz} onChange={(e) => setTz(e.target.value)} className="mt-1" />
        </label>
        <Button onClick={save}>Save</Button>
      </section>
      <section className="panel space-y-3 p-5">
        <h2 className="font-display text-sm text-primary">DATA</h2>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={exportData}>Export my data</Button>
          <Button variant="outline" onClick={() => supabase.auth.signOut()}>Sign out</Button>
          <Button variant="destructive" onClick={removeAccount}>Delete account</Button>
        </div>
      </section>
    </div>
  );
}
