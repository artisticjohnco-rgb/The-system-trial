import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { AppShell, PageTitle } from "@/components/AppShell";
import { QuestCard } from "@/components/QuestCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useLog, useProfile, useQuests } from "@/lib/data";
import { ATTRIBUTES, DIFFICULTIES } from "@/lib/game";
import { questStatus } from "@/lib/quest-status";

export const Route = createFileRoute("/quests")({
  head: () => ({
    meta: [
      { title: "Quests — The System" },
      { name: "description", content: "Create and complete daily and one-time quests to earn XP." },
      { property: "og:title", content: "Quests — The System" },
      { property: "og:description", content: "Create and complete daily and one-time quests to earn XP." },
    ],
  }),
  component: () => (
    <AppShell>
      <Quests />
    </AppShell>
  ),
});

const selectCls = "h-9 rounded-md border border-input bg-background px-3 text-sm";

function Quests() {
  const qc = useQueryClient();
  const { data: p } = useProfile();
  const { data: quests } = useQuests();
  const { data: log } = useLog(p?.timezone);
  const [form, setForm] = useState({ title: "", description: "", attribute: "discipline", difficulty: "D", recurrence: "daily", due_date: "" });
  const [busy, setBusy] = useState(false);

  async function create(e: React.FormEvent) {
    e.preventDefault();
    if (!p) return;
    setBusy(true);
    const { error } = await supabase.from("quests").insert({
      user_id: p.id,
      title: form.title.trim(),
      description: form.description.trim(),
      attribute: form.attribute,
      difficulty: form.difficulty,
      recurrence: form.recurrence,
      due_date: form.recurrence === "once" && form.due_date ? form.due_date : null,
    });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("NEW QUEST REGISTERED.");
    setForm({ ...form, title: "", description: "" });
    qc.invalidateQueries({ queryKey: ["quests"] });
  }

  async function remove(id: string) {
    if (!confirm("Abandon this quest? Its history will be kept.")) return;
    const { error } = await supabase.from("quests").update({ archived: true }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["quests"] });
  }

  const daily = quests?.filter((q) => q.recurrence === "daily") ?? [];
  const once = quests?.filter((q) => q.recurrence === "once") ?? [];

  return (
    <div className="space-y-8">
      <PageTitle kicker="[ QUEST LOG ]" title="QUESTS" />
      <form onSubmit={create} className="panel space-y-3 p-5">
        <h2 className="font-display text-sm text-primary">NEW QUEST</h2>
        <Input required maxLength={120} placeholder="Quest title — e.g. Run 5 km" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <Input placeholder="Completion requirement (optional)" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        <div className="flex flex-wrap gap-2">
          <select className={selectCls} value={form.attribute} onChange={(e) => setForm({ ...form, attribute: e.target.value })}>
            {ATTRIBUTES.map((a) => <option key={a.key} value={a.key}>{a.label}</option>)}
          </select>
          <select className={selectCls} value={form.difficulty} onChange={(e) => setForm({ ...form, difficulty: e.target.value })}>
            {DIFFICULTIES.map((d) => <option key={d.key} value={d.key}>{d.label} ({d.xp} XP)</option>)}
          </select>
          <select className={selectCls} value={form.recurrence} onChange={(e) => setForm({ ...form, recurrence: e.target.value })}>
            <option value="daily">Daily</option>
            <option value="once">One-time</option>
          </select>
          {form.recurrence === "once" && (
            <input type="date" className={selectCls} value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} />
          )}
          <Button type="submit" disabled={busy} className="ml-auto font-display">ADD</Button>
        </div>
      </form>

      {quests && log && (
        <>
          <Section title="DAILY QUESTS" empty="No daily quests yet.">
            {daily.map((q) => <QuestCard key={q.id} quest={q} status={questStatus(q, log.rows, log.today)} onDelete={() => remove(q.id)} />)}
          </Section>
          <Section title="MISSIONS" empty="No one-time missions.">
            {once.map((q) => <QuestCard key={q.id} quest={q} status={questStatus(q, log.rows, log.today)} onDelete={() => remove(q.id)} />)}
          </Section>
        </>
      )}
    </div>
  );
}

function Section({ title, empty, children }: { title: string; empty: string; children: React.ReactNode[] }) {
  return (
    <section>
      <h2 className="mb-3 font-display text-sm text-primary">{title}</h2>
      <div className="space-y-3">
        {children.length ? children : <p className="text-muted-foreground">{empty}</p>}
      </div>
    </section>
  );
}
