import { createFileRoute } from "@tanstack/react-router";
import { Lock, Trophy } from "lucide-react";
import { AppShell, PageTitle } from "@/components/AppShell";
import { useAchievements } from "@/lib/data";
import { ACHIEVEMENTS } from "@/lib/game";

export const Route = createFileRoute("/achievements")({
  head: () => ({
    meta: [
      { title: "Achievements — The System" },
      { name: "description", content: "Unlocked titles and milestones earned through real progress." },
      { property: "og:title", content: "Achievements — The System" },
      { property: "og:description", content: "Unlocked titles and milestones earned through real progress." },
    ],
  }),
  component: () => (
    <AppShell>
      <Achievements />
    </AppShell>
  ),
});

function Achievements() {
  const { data } = useAchievements();
  const got = new Map(data?.map((a) => [a.key, a.unlocked_at]));
  return (
    <div>
      <PageTitle kicker={`[ ${got.size} / ${ACHIEVEMENTS.length} UNLOCKED ]`} title="ACHIEVEMENTS" />
      <div className="grid gap-3 sm:grid-cols-2">
        {ACHIEVEMENTS.map((a) => {
          const at = got.get(a.key);
          return (
            <div key={a.key} className={`panel flex items-center gap-4 p-4 ${at ? "glow-strong" : "opacity-50"}`}>
              <div className={`grid h-11 w-11 shrink-0 place-items-center rounded-md border ${at ? "border-primary text-primary" : "text-muted-foreground"}`}>
                {at ? <Trophy className="h-5 w-5" /> : <Lock className="h-5 w-5" />}
              </div>
              <div className="min-w-0">
                <div className="truncate text-lg font-bold">{a.title}</div>
                <div className="text-sm text-muted-foreground">{a.desc}</div>
                {at && <div className="text-xs text-primary">Unlocked {new Date(at).toLocaleDateString()}</div>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
