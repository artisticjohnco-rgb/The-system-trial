import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Awaken — The System" },
      { name: "description", content: "Sign in or create your player account to begin leveling up." },
      { property: "og:title", content: "Awaken — The System" },
      { property: "og:description", content: "Sign in or create your player account to begin leveling up." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => data.session && navigate({ to: "/" }));
    const { data } = supabase.auth.onAuthStateChange((_e, s) => s && navigate({ to: "/" }));
    return () => data.subscription.unsubscribe();
  }, [navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    if (mode === "up") {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { emailRedirectTo: window.location.origin, data: { display_name: name || undefined } },
      });
      if (error) toast.error(error.message);
      else if (!data.session) toast.success("Check your email to confirm your account.");
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) toast.error(error.message);
    }
    setBusy(false);
  }

  return (
    <div className="grid min-h-screen place-items-center p-4">
      <div className="panel scanline animate-system-in w-full max-w-md p-8">
        <div className="text-center font-display text-xs text-muted-foreground">[ NOTIFICATION ]</div>
        <h1 className="mt-3 text-center font-display text-xl font-bold text-primary text-glow">
          YOU HAVE BEEN CHOSEN AS A PLAYER.
        </h1>
        <p className="mt-2 text-center text-muted-foreground">Your potential is not your current level.</p>
        <form onSubmit={submit} className="mt-8 space-y-3">
          {mode === "up" && <Input placeholder="Player name" value={name} onChange={(e) => setName(e.target.value)} />}
          <Input type="email" required placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input type="password" required minLength={6} placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <Button type="submit" disabled={busy} className="w-full font-display">
            {mode === "in" ? "ENTER THE SYSTEM" : "ACCEPT"}
          </Button>
        </form>
        <button
          onClick={() => setMode(mode === "in" ? "up" : "in")}
          className="mt-6 w-full text-sm text-muted-foreground hover:text-primary"
        >
          {mode === "in" ? "New player? Create an account" : "Already a player? Sign in"}
        </button>
      </div>
    </div>
  );
}
