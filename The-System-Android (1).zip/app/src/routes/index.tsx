import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell, XpBar } from "@/components/AppShell";
import { QuestCard } from "@/components/QuestCard";
import { useAchievements, useLog, useProfile, useQuests } from "@/lib/data";
import { ATTRIBUTES, achievementTitle, rankFor, xpForLevel } from "@/lib/game";
import { questStatus } from "@/lib/quest-status";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "System Status — The System" },
      { name: "description", content: "Your daily briefing: level, XP, streak and today's quests." },
      { property: "og:title", content: "System Status — The System" },
      { property: "og:description", content: "Your daily briefing: level, XP, streak and today's quests." },
    ],
  }),
  component: () => (
    <AppShell>
      <Home />
    </AppShell>
  ),
});

function Home() {
  const { data: p } = useProfile();
  const { data: quests } = useQuests();
  const { data: log } = useLog(p?.timezone);
  const { data: ach } = useAchievements();
  if (!p || !quests || !log) return <p className="text-muted-foreground">Loading status…</p>;

  const daily = quests.filter((q) => q.recurrence === "daily");
  const done = daily.filter((q) => questStatus(q, log.rows, log.today) === "completed").length;
  const todayRows = log.rows.filter((l) => l.day === log.today && l.outcome === "completed");
  const score = daily.length ? Math.round((done / daily.length) * 100) : 0;
  const need = xpForLevel(p.level);

  return (
    <div className="space-y-6">
      <section className="panel scanline animate-system-in p-6">
        <div className="font-display text-xs text-muted-foreground">[ STATUS ]</div>
        <div className="mt-3 grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4">
          <div className="min-w-0">
            <h1 className="truncate font-display text-2xl font-bold md:text-3xl">{p.display_name}</h1>
            <p className="text-muted-foreground">Rank {rankFor(p.level)} Hunter</p>
          </div>
          <div className="text-right">
            <div className="font-display text-xs text-muted-foreground">LEVEL</div>
            <div className="font-display text-5xl font-black text-primary text-glow">{p.level}</div>
          </div>
        </div>
        <div className="mt-5">
          <div className="mb-1 flex justify-between text-sm text-muted-foreground">
            <span>XP</span>
            <span>{p.xp} / {need}</span>
          </div>
          <XpBar value={p.xp} max={need} />
        </div>
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Stat label="Streak" value={`${p.current_streak}d`} sub={`Best ${p.longest_streak}d`} />
          <Stat label="Quests done" value={p.quests_completed} />
          <Stat label="Today's score" value={`${score}%`} sub={`+${todayRows.reduce((s, r) => s + r.xp, 0)} XP today`} />
          <Stat label="Points" value={p.attribute_points} sub="to allocate" highlight={p.attribute_points > 0} />
        </div>
      </section>

      <section>
        <div className="mb-3 flex items-baseline justify-between">
          <h2 className="font-display text-sm text-primary">
            {done === daily.length && daily.length > 0 ? "DAILY QUEST COMPLETED." : "DAILY QUEST AVAILABLE."}
          </h2>
          <span className="text-sm text-muted-foreground">{done}/{daily.length} cleared</span>
        </div>
        <div className="space-y-3">
          {daily.map((q) => (
            <QuestCard key={q.id} quest={q} status={questStatus(q, log.rows, log.today)} />
          ))}
          {daily.length === 0 && (
            <div className="panel p-6 text-center text-muted-foreground">
              No daily quests. <Link to="/quests" className="text-primary">Create one</Link>.
            </div>
          )}
        </div>
        {done < daily.length && (
          <p className="mt-3 text-sm text-warning">WARNING: Incomplete daily quests at midnight cost half their XP.</p>
        )}
      </section>

      <div className="grid gap-6 md:grid-cols-2">
        <section className="panel p-5">
          <h2 className="mb-3 font-display text-sm text-primary">ATTRIBUTES</h2>
          <div className="grid grid-cols-3 gap-2">
            {ATTRIBUTES.map((a) => (
              <div key={a.key} className="rounded-md bg-muted/50 px-2 py-1.5 text-center">
                <div className="font-display text-[10px] text-muted-foreground">{a.short}</div>
                <div className="font-bold">{Number(p.attributes[a.key] ?? 10).toFixed(1)}</div>
              </div>
            ))}
          </div>
          <Link to="/character" className="mt-3 inline-block text-sm text-primary">Open status window →</Link>
        </section>
        <section className="panel p-5">
          <h2 className="mb-3 font-display text-sm text-primary">RECENT ACHIEVEMENTS</h2>
          {ach && ach.length > 0 ? (
            <ul className="space-y-2">
              {ach.slice(0, 5).map((a) => (
                <li key={a.id} className="flex justify-between">
                  <span className="font-semibold">{achievementTitle(a.key)}</span>
                  <span className="text-sm text-muted-foreground">{new Date(a.unlocked_at).toLocaleDateString()}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-muted-foreground">Complete your first quest to awaken.</p>
          )}
        </section>
      </div>
    </div>
  );
}

function Stat({ label, value, sub, highlight }: { label: string; value: string | number; sub?: string; highlight?: boolean }) {
  return (
    <div className={`rounded-md border bg-muted/40 p-3 ${highlight ? "border-primary glow-strong" : ""}`}>
      <div className="font-display text-[10px] text-muted-foreground">{label.toUpperCase()}</div>
      <div className="text-2xl font-bold">{value}</div>
      {sub && <div className="text-xs text-muted-foreground">{sub}</div>}
    </div>
  );
}
