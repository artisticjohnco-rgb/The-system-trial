import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { todayIn } from "./game";

async function uid() {
  const { data } = await supabase.auth.getUser();
  if (!data.user) throw new Error("Not signed in");
  return data.user.id;
}

export function useProfile() {
  return useQuery({
    queryKey: ["profile"],
    queryFn: async () => {
      const id = await uid();
      const { data, error } = await supabase.from("profiles").select("*").eq("id", id).single();
      if (error) throw error;
      return { ...data, attributes: data.attributes as Record<string, number> };
    },
  });
}

export function useQuests() {
  return useQuery({
    queryKey: ["quests"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("quests")
        .select("*")
        .eq("archived", false)
        .order("created_at");
      if (error) throw error;
      return data;
    },
  });
}

export function useLog(tz: string | undefined) {
  return useQuery({
    queryKey: ["log"],
    enabled: !!tz,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("quest_log")
        .select("*")
        .order("day", { ascending: false })
        .limit(1000);
      if (error) throw error;
      return { rows: data, today: todayIn(tz!) };
    },
  });
}

export function useAchievements() {
  return useQuery({
    queryKey: ["achievements"],
    queryFn: async () => {
      const { data, error } = await supabase.from("achievements").select("*").order("unlocked_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });
}

export function useHistory() {
  return useQuery({
    queryKey: ["history"],
    queryFn: async () => {
      const [a, l] = await Promise.all([
        supabase.from("attribute_history").select("*").order("created_at", { ascending: false }).limit(50),
        supabase.from("level_history").select("*").order("created_at", { ascending: false }).limit(50),
      ]);
      if (a.error) throw a.error;
      if (l.error) throw l.error;
      return { attributes: a.data, levels: l.data };
    },
  });
}

export function useRefreshAll() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries();
}
