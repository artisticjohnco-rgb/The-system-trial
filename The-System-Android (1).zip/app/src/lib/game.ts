export const ATTRIBUTES = [
  { key: "strength", label: "Strength", short: "STR", desc: "Resistance training, athletic performance, muscular development." },
  { key: "vitality", label: "Vitality", short: "VIT", desc: "Sleep, recovery, endurance, nutrition, health habits." },
  { key: "intelligence", label: "Intelligence", short: "INT", desc: "Reasoning, problem-solving, critical thinking." },
  { key: "knowledge", label: "Knowledge", short: "KNW", desc: "Books read, subjects studied, skills learned." },
  { key: "discipline", label: "Discipline", short: "DIS", desc: "Consistency, delayed gratification, keeping commitments." },
  { key: "charisma", label: "Charisma", short: "CHA", desc: "Communication, confidence, public speaking." },
  { key: "wealth", label: "Wealth", short: "WLT", desc: "Income, savings, financial stability." },
  { key: "career", label: "Career", short: "CAR", desc: "Professional skills, output, career milestones." },
  { key: "social", label: "Social", short: "SOC", desc: "Friendships, networking, community." },
  { key: "romance", label: "Romance", short: "ROM", desc: "Relationship skills, emotional maturity." },
  { key: "resilience", label: "Mental Resilience", short: "RES", desc: "Emotional regulation, stress management, perseverance." },
  { key: "experience", label: "Experience", short: "EXP", desc: "New experiences, travel, comfort-zone challenges." },
] as const;

export type AttributeKey = (typeof ATTRIBUTES)[number]["key"];
export const attrLabel = (k: string) => ATTRIBUTES.find((a) => a.key === k)?.label ?? k;
export const attrShort = (k: string) => ATTRIBUTES.find((a) => a.key === k)?.short ?? k;

export const DIFFICULTIES = [
  { key: "E", xp: 10, label: "E — Trivial" },
  { key: "D", xp: 15, label: "D — Easy" },
  { key: "C", xp: 25, label: "C — Moderate" },
  { key: "B", xp: 50, label: "B — Hard" },
  { key: "A", xp: 100, label: "A — Very hard" },
  { key: "S", xp: 250, label: "S — Major milestone" },
] as const;
export const difficultyXp = (d: string) => DIFFICULTIES.find((x) => x.key === d)?.xp ?? 10;

// Must match public.xp_for_level in the database.
export const xpForLevel = (l: number) => Math.trunc(100 * Math.pow(l, 1.5));

export function rankFor(level: number) {
  if (level >= 80) return "S";
  if (level >= 50) return "A";
  if (level >= 30) return "B";
  if (level >= 15) return "C";
  if (level >= 5) return "D";
  return "E";
}

export const ACHIEVEMENTS = [
  { key: "first_quest", title: "Awakening", desc: "Complete your first quest." },
  { key: "daily_clear", title: "Daily Clear", desc: "Complete every daily quest in one day." },
  { key: "quests_10", title: "Initiate", desc: "Complete 10 quests." },
  { key: "quests_50", title: "Hunter", desc: "Complete 50 quests." },
  { key: "quests_200", title: "Relentless", desc: "Complete 200 quests." },
  { key: "streak_3", title: "Momentum", desc: "Reach a 3-day streak." },
  { key: "streak_7", title: "Iron Week", desc: "Reach a 7-day streak." },
  { key: "streak_30", title: "Unbreakable", desc: "Reach a 30-day streak." },
  { key: "level_5", title: "D-Rank Ascension", desc: "Reach level 5." },
  { key: "level_10", title: "Rising Hunter", desc: "Reach level 10." },
  { key: "level_25", title: "Elite", desc: "Reach level 25." },
] as const;
export const achievementTitle = (k: string) => ACHIEVEMENTS.find((a) => a.key === k)?.title ?? k;

export function todayIn(tz: string) {
  try {
    return new Intl.DateTimeFormat("en-CA", { timeZone: tz }).format(new Date());
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}
