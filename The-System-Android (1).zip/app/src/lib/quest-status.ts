import type { Tables } from "@/integrations/supabase/types";

export function questStatus(q: Tables<"quests">, log: Tables<"quest_log">[], today: string) {
  const rows = log.filter((l) => l.quest_id === q.id);
  const entry = q.recurrence === "daily" ? rows.find((l) => l.day === today) : rows[0];
  return (entry?.outcome as "completed" | "failed" | undefined) ?? "pending";
}
