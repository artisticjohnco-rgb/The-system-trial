-- Lets a signed-in player delete their own account from the app.
-- Replaces the former server function (which needed a server runtime that the
-- native Android build does not have). Runs as the database owner, but only
-- ever deletes the row belonging to auth.uid().
create or replace function public.delete_my_account()
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
begin
  if uid is null then
    raise exception 'Not authenticated';
  end if;

  delete from public.quest_log where user_id = uid;
  delete from public.quests where user_id = uid;
  delete from public.attribute_history where user_id = uid;
  delete from public.level_history where user_id = uid;
  delete from public.achievements where user_id = uid;
  -- profiles rows cascade from auth.users
  delete from auth.users where id = uid;
end;
$$;

revoke execute on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;
