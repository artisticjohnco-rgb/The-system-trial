// Builds the static web app for Capacitor and prepares it as dist/native/index.html.
// Usage: node scripts/build-native.mjs
import { spawnSync } from "node:child_process";
import { cpSync, existsSync, renameSync, rmSync } from "node:fs";
import { join } from "node:path";

const root = process.cwd();
const run = (cmd, args, env = {}) => {
  const r = spawnSync(cmd, args, { stdio: "inherit", env: { ...process.env, ...env }, shell: process.platform === "win32" });
  if (r.status !== 0) process.exit(r.status ?? 1);
};

run("npx", ["vite", "build"], { CAPACITOR_BUILD: "1" });

const client = join(root, "dist", "client");
const native = join(root, "dist", "native");
const shell = join(client, "_shell.html");
if (!existsSync(shell)) {
  console.error(`Expected ${shell} after build. The SPA shell was not generated.`);
  process.exit(1);
}

rmSync(native, { recursive: true, force: true });
cpSync(client, native, { recursive: true });
renameSync(join(native, "_shell.html"), join(native, "index.html"));
console.log("Native web bundle ready at dist/native (index.html).");
