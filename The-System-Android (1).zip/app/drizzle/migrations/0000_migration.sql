
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Hunter',
  avatar_color text not null default 'cyan',
  timezone text not null default 'UTC',
  level int not null default 1,
  xp int not null default 0,
  total_xp int not null default 0,
  attribute_points int not null default 0,
  attributes jsonb not null default '{"strength":10,"vitality":10,"intelligence":10,"knowledge":10,"discipline":10,"charisma":10,"wealth":10,"career":10,"social":10,"romance":10,"resilience":10,"experience":10}',
  current_streak int not null default 0,
  longest_streak int not null default 0,
  last_streak_day date,
  quests_completed int not null default 0,
  last_sync_day date,
  created_at timestamptz not null default now()
);
create table public.quests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  title text not null,
  description text not null default '',
  attribute text not null,
  difficulty text not null default 'E',
  recurrence text not null default 'daily',
  due_date date,
  archived boolean not null default false,
  created_at timestamptz not null default now()
);
create table public.quest_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  quest_id uuid not null references public.quests(id) on delete cascade,
  day date not null,
  outcome text not null,
  xp int not null default 0,
  created_at timestamptz not null default now(),
  unique (quest_id, day)
);
create table public.attribute_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  attribute text not null,
  delta numeric not null,
  reason text not null,
  created_at timestamptz not null default now()
);
create table public.level_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  level int not null,
  created_at timestamptz not null default now()
);
create table public.achievements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  key text not null,
  unlocked_at timestamptz not null default now(),
  unique (user_id, key)
);

grant select, update on public.profiles to authenticated;
grant select, insert, update, delete on public.quests to authenticated;
grant select on public.quest_log, public.attribute_history, public.level_history, public.achievements to authenticated;
grant all on public.profiles, public.quests, public.quest_log, public.attribute_history, public.level_history, public.achievements to service_role;

alter table public.profiles enable row level security;
alter table public.quests enable row level security;
alter table public.quest_log enable row level security;
alter table public.attribute_history enable row level security;
alter table public.level_history enable row level security;
alter table public.achievements enable row level security;

create policy "own profile read" on public.profiles for select to authenticated using (id = auth.uid());
create policy "own profile update" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "own quests" on public.quests for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own log" on public.quest_log for select to authenticated using (user_id = auth.uid());
create policy "own attr hist" on public.attribute_history for select to authenticated using (user_id = auth.uid());
create policy "own level hist" on public.level_history for select to authenticated using (user_id = auth.uid());
create policy "own achievements" on public.achievements for select to authenticated using (user_id = auth.uid());

-- Prevent users from editing progression fields directly
revoke update on public.profiles from authenticated;
grant update (display_name, avatar_color, timezone) on public.profiles to authenticated;

create or replace function public.xp_for_level(l int) returns int language sql immutable as $$
  select (100 * power(l, 1.5))::int
$$;

create or replace function public.difficulty_xp(d text) returns int language sql immutable as $$
  select case d when 'E' then 10 when 'D' then 15 when 'C' then 25 when 'B' then 50 when 'A' then 100 when 'S' then 250 else 10 end
$$;

create or replace function public.difficulty_attr(d text) returns numeric language sql immutable as $$
  select case d when 'E' then 0.2 when 'D' then 0.3 when 'C' then 0.5 when 'B' then 0.8 when 'A' then 1.2 when 'S' then 2 else 0.2 end
$$;

create or replace function public.validate_quest() returns trigger language plpgsql set search_path = public as $$
begin
  if new.difficulty not in ('E','D','C','B','A','S') then raise exception 'Invalid difficulty'; end if;
  if new.recurrence not in ('daily','once') then raise exception 'Invalid recurrence'; end if;
  if new.attribute not in ('strength','vitality','intelligence','knowledge','discipline','charisma','wealth','career','social','romance','resilience','experience') then raise exception 'Invalid attribute'; end if;
  if length(trim(new.title)) = 0 or length(new.title) > 120 then raise exception 'Invalid title'; end if;
  return new;
end $$;
create trigger quests_validate before insert or update on public.quests for each row execute function public.validate_quest();

create or replace function public.user_today(p_uid uuid) returns date language sql stable security definer set search_path = public as $$
  select (now() at time zone coalesce((select timezone from public.profiles where id = p_uid), 'UTC'))::date
$$;

create or replace function public.grant_achievement(p_uid uuid, p_key text) returns boolean language plpgsql security definer set search_path = public as $$
begin
  insert into public.achievements(user_id, key) values (p_uid, p_key) on conflict do nothing;
  return found;
end $$;

create or replace function public.check_achievements(p_uid uuid) returns text[] language plpgsql security definer set search_path = public as $$
declare p public.profiles; res text[] := '{}';
begin
  select * into p from public.profiles where id = p_uid;
  if p.quests_completed >= 1 and public.grant_achievement(p_uid,'first_quest') then res := res || 'first_quest'; end if;
  if p.quests_completed >= 10 and public.grant_achievement(p_uid,'quests_10') then res := res || 'quests_10'; end if;
  if p.quests_completed >= 50 and public.grant_achievement(p_uid,'quests_50') then res := res || 'quests_50'; end if;
  if p.quests_completed >= 200 and public.grant_achievement(p_uid,'quests_200') then res := res || 'quests_200'; end if;
  if p.current_streak >= 3 and public.grant_achievement(p_uid,'streak_3') then res := res || 'streak_3'; end if;
  if p.current_streak >= 7 and public.grant_achievement(p_uid,'streak_7') then res := res || 'streak_7'; end if;
  if p.current_streak >= 30 and public.grant_achievement(p_uid,'streak_30') then res := res || 'streak_30'; end if;
  if p.level >= 5 and public.grant_achievement(p_uid,'level_5') then res := res || 'level_5'; end if;
  if p.level >= 10 and public.grant_achievement(p_uid,'level_10') then res := res || 'level_10'; end if;
  if p.level >= 25 and public.grant_achievement(p_uid,'level_25') then res := res || 'level_25'; end if;
  return res;
end $$;

create or replace function public.complete_quest(p_quest uuid) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid(); q public.quests; p public.profiles; today date; gain int; again numeric;
  start_level int; daily_total int; daily_done int; ach text[];
begin
  if uid is null then raise exception 'Not authenticated'; end if;
  select * into q from public.quests where id = p_quest and user_id = uid and not archived;
  if not found then raise exception 'Quest not found'; end if;
  select * into p from public.profiles where id = uid for update;
  today := public.user_today(uid);
  if q.recurrence = 'once' and exists (select 1 from public.quest_log where quest_id = q.id) then
    raise exception 'Quest already resolved';
  end if;
  if q.recurrence = 'once' and q.due_date is not null and q.due_date < today then
    raise exception 'Deadline passed';
  end if;
  gain := public.difficulty_xp(q.difficulty);
  again := public.difficulty_attr(q.difficulty);
  begin
    insert into public.quest_log(user_id, quest_id, day, outcome, xp) values (uid, q.id, today, 'completed', gain);
  exception when unique_violation then
    raise exception 'Quest already completed today';
  end;
  start_level := p.level;
  p.xp := p.xp + gain;
  p.total_xp := p.total_xp + gain;
  while p.xp >= public.xp_for_level(p.level) loop
    p.xp := p.xp - public.xp_for_level(p.level);
    p.level := p.level + 1;
    p.attribute_points := p.attribute_points + 3;
    insert into public.level_history(user_id, level) values (uid, p.level);
  end loop;
  p.attributes := jsonb_set(p.attributes, array[q.attribute], to_jsonb(round(coalesce((p.attributes->>q.attribute)::numeric,10) + again, 1)));
  insert into public.attribute_history(user_id, attribute, delta, reason) values (uid, q.attribute, again, 'Quest: ' || q.title);
  p.quests_completed := p.quests_completed + 1;

  select count(*) into daily_total from public.quests where user_id = uid and recurrence = 'daily' and not archived;
  select count(*) into daily_done from public.quest_log l join public.quests qq on qq.id = l.quest_id
    where l.user_id = uid and l.day = today and l.outcome = 'completed' and qq.recurrence = 'daily' and not qq.archived;
  if daily_total > 0 and daily_done >= daily_total and (p.last_streak_day is null or p.last_streak_day < today) then
    if p.last_streak_day = today - 1 then p.current_streak := p.current_streak + 1; else p.current_streak := 1; end if;
    p.last_streak_day := today;
    p.longest_streak := greatest(p.longest_streak, p.current_streak);
  end if;

  update public.profiles set xp = p.xp, total_xp = p.total_xp, level = p.level, attribute_points = p.attribute_points,
    attributes = p.attributes, quests_completed = p.quests_completed, current_streak = p.current_streak,
    longest_streak = p.longest_streak, last_streak_day = p.last_streak_day where id = uid;
  ach := public.check_achievements(uid);
  if daily_total > 0 and daily_done >= daily_total and public.grant_achievement(uid, 'daily_clear') then ach := ach || 'daily_clear'; end if;
  return jsonb_build_object('xp', gain, 'attribute', q.attribute, 'attribute_gain', again,
    'leveled_up', p.level > start_level, 'level', p.level, 'achievements', to_jsonb(ach), 'daily_clear', daily_total > 0 and daily_done >= daily_total);
end $$;

create or replace function public.sync_day() returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); p public.profiles; today date; d date; q record; failed int := 0; penalty int := 0; startd date;
begin
  if uid is null then raise exception 'Not authenticated'; end if;
  select * into p from public.profiles where id = uid for update;
  today := public.user_today(uid);
  if p.last_sync_day is not null and p.last_sync_day >= today then
    return jsonb_build_object('failed', 0, 'penalty', 0);
  end if;
  startd := greatest(coalesce(p.last_sync_day, today), today - 7);
  for q in select * from public.quests where user_id = uid and recurrence = 'daily' and not archived loop
    d := greatest(startd, (q.created_at at time zone p.timezone)::date);
    while d < today loop
      insert into public.quest_log(user_id, quest_id, day, outcome, xp)
        values (uid, q.id, d, 'failed', -(public.difficulty_xp(q.difficulty) / 2)) on conflict do nothing;
      if found then failed := failed + 1; penalty := penalty + public.difficulty_xp(q.difficulty) / 2; end if;
      d := d + 1;
    end loop;
  end loop;
  for q in select * from public.quests where user_id = uid and recurrence = 'once' and not archived and due_date is not null and due_date < today
    and not exists (select 1 from public.quest_log l where l.quest_id = quests.id) loop
    insert into public.quest_log(user_id, quest_id, day, outcome, xp) values (uid, q.id, q.due_date, 'failed', -(public.difficulty_xp(q.difficulty)/2)) on conflict do nothing;
    if found then failed := failed + 1; penalty := penalty + public.difficulty_xp(q.difficulty)/2; end if;
  end loop;
  if p.last_streak_day is null or p.last_streak_day < today - 1 then p.current_streak := 0; end if;
  update public.profiles set xp = greatest(0, xp - penalty), current_streak = p.current_streak, last_sync_day = today where id = uid;
  return jsonb_build_object('failed', failed, 'penalty', penalty);
end $$;

create or replace function public.allocate_point(p_attr text) returns void language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'Not authenticated'; end if;
  if p_attr not in ('strength','vitality','intelligence','knowledge','discipline','charisma','wealth','career','social','romance','resilience','experience') then raise exception 'Invalid attribute'; end if;
  update public.profiles set attribute_points = attribute_points - 1,
    attributes = jsonb_set(attributes, array[p_attr], to_jsonb(round(coalesce((attributes->>p_attr)::numeric,10) + 1, 1)))
    where id = uid and attribute_points > 0;
  if not found then raise exception 'No attribute points available'; end if;
  insert into public.attribute_history(user_id, attribute, delta, reason) values (uid, p_attr, 1, 'Attribute point allocated');
end $$;

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, display_name) values (new.id, coalesce(new.raw_user_meta_data->>'display_name', new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1), 'Hunter'));
  insert into public.quests(user_id, title, description, attribute, difficulty, recurrence) values
    (new.id, '50 Push-ups', 'Complete 50 push-ups in any number of sets.', 'strength', 'D', 'daily'),
    (new.id, 'Read 20 Pages', 'Read at least 20 pages of a non-fiction book.', 'knowledge', 'D', 'daily'),
    (new.id, 'Deep Work — 60 min', 'One focused, distraction-free work session.', 'career', 'C', 'daily'),
    (new.id, 'Sleep Before Midnight', 'In bed before 00:00, 7+ hours.', 'vitality', 'E', 'daily');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

revoke execute on function public.grant_achievement(uuid, text) from public, anon, authenticated;
revoke execute on function public.check_achievements(uuid) from public, anon, authenticated;
revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke execute on function public.user_today(uuid) from public, anon;
revoke execute on function public.complete_quest(uuid), public.sync_day(), public.allocate_point(text) from public, anon;
grant execute on function public.complete_quest(uuid), public.sync_day(), public.allocate_point(text) to authenticated;
